package com.ifal2.recuperacao.controle;

import java.util.Optional;

import com.ifal2.recuperacao.modelo.Carro;
import com.ifal2.recuperacao.repositorio.RepositorioCarro;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@RestController
public class Controle{

//awt
  @Autowired
  RepositorioCarro rep;

    @RequestMapping("/")
    public ModelAndView index(){
        ModelAndView model = new ModelAndView("index.html");
        return model;
    }
    
    @RequestMapping("/formulario")
    public ModelAndView formulario(Carro carro){
        ModelAndView model = new ModelAndView("formulario.html");
        return model;
    }

    @RequestMapping("/salvar")
    public ModelAndView salvar(Carro carro, RedirectAttributes redirect){
        ModelAndView model = new ModelAndView("redirect:/lista");
        rep.save(carro);

        return model;
 
    }
    @RequestMapping("/lista")
    public ModelAndView listar(){
        ModelAndView model = new ModelAndView("listar.html");
        //proxima linha pega todos objetos
        Iterable<Carro> carros = rep.findAll();
        //após pegar os valores ele passa para próxima tela no caso LISTAR
        model.addObject("carros", carros);

        return model;
    }

    @RequestMapping("/atualizar/{id}")
    public ModelAndView atualizar(@PathVariable("id")long id){
        ModelAndView model = new ModelAndView("formulario.html");
        Optional <Carro> opcao = rep.findById(id);

        Carro carro = opcao.get();
        model.addObject("carro", carro);

        
        return model;


    }
    
    @RequestMapping("/excluir/{id}")
    public ModelAndView excluir(@PathVariable("id")long id, RedirectAttributes redirect){
        ModelAndView model = new ModelAndView("redirect:/lista");
        Optional <Carro> opcao = rep.findById(id);

        Carro carro = opcao.get();
       rep.deleteById(carro.getId());

        
        return model;


    }
}