///criação da interface
package com.ifal2.recuperacao.repositorio;

import com.ifal2.recuperacao.modelo.Carro;

import org.springframework.data.repository.CrudRepository;

public interface RepositorioCarro extends CrudRepository <Carro, Long> {
    

}

